export const colors = [
    '#F47F66',
    '#99A85A',
    '#5AA886',
    '#4BADAA',
    '#C9D5A5',
    '#656B9C',
    '#9068A7',
    '#C682B6',
    '#A24C6F',
    '#D09C8F',
    '#7AB5C8'
];
